<?php

include("connection.php");

 if (isset($_GET['pageno']))
{
            $pageno = $_GET['pageno'];
        } 
        else {
            $pageno = 1;
        }

if (isset($_GET['tags']))
    {   
       
        $no_of_records_per_page = 10;
        $offset = ($pageno-1) * $no_of_records_per_page;
        
        $total_pages_sql = "SELECT COUNT(*) FROM playstore_apps_data";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);
        
        // $idd=mysqli_real_escape_string($con,$_GET['cat']);
        $req_tag=$_GET['tags'];
        
        // $qy=$con->prepare("SELECT * FROM playstore_apps_data WHERE id=?  ");
        // $qy->bind_param("s",$idd);
        // $qy->execute();
        // $resulttt=$qy->get_result();
        // if($resulttt->num_rows>0)
        // {
        //     while($rw=$resulttt->fetch_assoc())
        //     {
        //         $cate=$rw['specific_cat'];
        //         $app_tag=['app_tags'];

        //     }
        //     $qy->close();
        // }

        
       
        // $idd = str_replace("%20"," ",$idd);
        // $idd=$_GET["cat"];
        $cat_query=$con->prepare("SELECT * FROM playstore_apps_data WHERE app_tags LIKE '%$req_tag%' LIMIT $offset, $no_of_records_per_page ");
	    // $cat_query->bind_param("s",$req_tag);
        $cat_query->execute();
        $resultt=$cat_query->get_result();
       
?>
<html>
    <head>
        <meta charset="utf-8">
    
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>
                Tag Page
        </title>

        <!--<link rel="stylesheet" type="text/css" href="css/bootstrap.css">-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="../../css/stylesheet.css">
        <link rel="shortcut icon" href="../../img/favicon.png" type="image/x-icon">

        <script src="https://kit.fontawesome.com/4cc19ef96e.js" crossorigin="anonymous"></script>
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


    </head>

    <body>
        
        
            <div class="fluid-container sticky-top" id="navbar-header" >
                <div class="container">
                    <div class="row">
                        <div class="col-4">
                            <br>
                            <a href="https://thetoolstation.net"><h3 style="color: #fff;">Apps on Windows</h3></a>
                        </div>
                        <div class="col-8 ">

                            <br>
                            <br>

                            <nav class="" id="ul-container">
                                
                                <ul>
                                    <li><a  href="https://thetoolstation.net">HOME</a></li>
                                    <li><a style="border: 3px solid; border-left-style: hidden; border-right-style: hidden; border-top-style: hidden;" href="https://thetoolstation.net/single">APPS</a></li>
                                    <li><a href="https://thetoolstation.net/contactus">CONTACT US</a></li>
                                    <li><a href="https://thetoolstation.net/aboutus">ABOUT US</a></li>
                                </ul>
                            </nav>    
                        </div>
                    </div>
                    
                </div>
            </div>
            <br>
            <br>
            <!-- <div class="container" id="search-container">
                
            </div> -->
            
            <div class="container" id="main-body">

                <div class="row">
                    <div class="col-2"></div>
                    <div class="col-8">
                            <!-- <form class="md-form active-cyan active-cyan-2 mb-3">
                                <input class="form-control" type="search" name="search_feild" placeholder="Search for Apps">
                                <button class="btn btn-primary">Search</button>
                            </form> -->
                           <form name="myForm" onsubmit="event.preventDefault(); validateMyForm();" class="input-group md-form form-sm form-2 pl-0" method="GET" action="https://thetoolstation.net/search">
                                <input class="form-control my-0 py-1 lime-border" id="uniqueID" name="search-feild" type="text" placeholder="Search for Apps" aria-label="Search">
                                <div class="input-group-append">
                                  <span type="submit" name="search_btn"  class="input-group-text lime lighten-2" id="basic-text1"><i  class="fas fa-search text-grey"
                                      aria-hidden="true"></i></span>
                                </div>
                              </form>
                               <script type="text/javascript">
                              function validateMyForm()
                                {
                                    var nameValue = document.getElementById("uniqueID").value;
                                  if(nameValue.length!=0)
                                  { 
                                      window.location.href = "https://thetoolstation.net/search/"+nameValue;
                                    // alert("validation failed false");
                                    // returnToPreviousPage();
                                    // return false;
                                  }
                                  else{
                                
                                  alert("Requesting Search For Blank Value "+nameValue);
                                //   return true;
                                }
                                }
                                  
                                </script>
                    </div>
                    <div class="col-2"></div>
                </div>
                <br>
                <br>
                <div class="row" style="padding: 15px;">
                    <div class="col-lg-8 col-md-8 col-sm-12">
                        
                    
                        <table  class="table table-striped  table-hover table-condensed">
                            <thead style="  opacity: 1; color: rgb(131, 40, 40);text-align:center;">
                                <tr>
                                <th COLSPAN="4" ><h3>Tag: <?php echo $req_tag ?></h3></th>
                                <!-- <th ><h3><?php //echo get_theme_mod('wp_fileinfo_table-col2-text','Extension Type Name'); ?></h3></th> -->
                                
                                </tr>
                            </thead>
                            <tbody style="text-align:center;">
                        <?php
                             if($resultt->num_rows>0)
                             {
                     
                                 while($m_row=$resultt->fetch_assoc())
                                 {
                                     $t_id=$m_row['id'];
                                     $playstore_id=$m_row['playstore_id'];
                                     $appliction_name=$m_row['app_name'];
                                     $app_dev=$m_row['developer'];
                                    //  $app_cat=$m_row['category'];
                                     $app_icon=$m_row['img_url'];
                                     $description=$m_row['description'];
                                    //  $app_version=$m_row['version'];
                                    //  $app_req_android=$m_row['required_android'];
                                     $app_size=$m_row['size'];
                                    //  $app_permissions=$m_row['permissions'];
                                    //  $app_dev_email=$m_row['dev_email'];
                                    //  $app_dev_web=$m_row['dev_website'];
                                    //  $app_dev_address=$m_row['dev_address'];
                                    //  $app_installs=$m_row['installs'];
                                     $app_specific_cat=$m_row['specific_cat'];
                                     $app_last_updated=$m_row['last_updated_on'];
                                     $app_slug=$m_row['slug'];
                                    //  $app_overall_rating=$m_row['overall_rating'];
                                    //  $app_apk_file=$m_row['apk_file'];
                             
                                     // echo "<h1>no working </h1>";
                                
                        ?>
                            
                                <tr>
                                
                                    <td><img src="<?php echo $app_icon ?>=w32"   alt="<?php echo $appliction_name ?>" >
                                    </td>
                                    <td style="text-align:left;"><span><a href="https://thetoolstation.net/single/<?php echo $app_slug ?>"><?php echo $appliction_name ?></a></span></td>
                                    <td style="text-align:left;"><?php echo $app_dev ?></td>
                                    <td style="text-align:left;"><?php echo $app_size ?></td>
                                    </tr>
                                    <?php 
                                    }
                             
                                    $cat_query->close();
                                }
                                else
                                {
                                  header("location:404page"); 
                                 
                                }
                        }
                            else
                            {
                              header("location:404page"); 
                             
                            }
                                     ?>
                                   
                                </tbody>
                            </table>
                        
                        <?php
                           
                          
                   
                      

                        ?>
                        <br>
                        <div>
                        <ul class="pagination" style="margin-left:20%;">
                            <li><a class="btn btn-secondary" href="https://thetoolstation.net/tag/1/<?php echo $req_tag ?>">First</a></li>
                            <li style="margin-left: 10px;" class="btn btn-primary" class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                                <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "https://thetoolstation.net/tag/".($pageno - 1)?>/<?php echo $req_tag; } ?>"><< Prev</a>
                            </li>
                            <li style="margin-left: 10px;" class="btn btn-primary" class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                                <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "https://thetoolstation.net/tag/".($pageno + 1)?>/<?php echo $req_tag; } ?>">Next >></a>
                            </li>
                            <li style="margin-left: 10px;" class="btn btn-secondary"><a href="https://thetoolstation.net/tag/<?php echo $total_pages; ?>/<?php echo $req_tag ?>">Last</a></li>
                        </ul>
                        </div>
                                        
                    </div>
                                
                              
                
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        
                           <?php
                            include("loadmore.php");
                           ?>
                            

                            
                            <div class="most-pop-apps">
                                <table  class="table table-striped  table-hover table-condensed">
                                    <thead style="  opacity: 1; color: rgb(131, 40, 40);text-align:center;">
                                        <tr>
                                        <th COLSPAN="2" ><h3>Games</h3></th>
                                        <!-- <th ><h3><?php //echo get_theme_mod('wp_fileinfo_table-col2-text','Extension Type Name'); ?></h3></th> -->
                                        
                                        </tr>
                                    </thead>
                                    <tbody style="text-align:center;">
                                                    
                                        <?php 
                                            $cat='Game';
                                            $game_guery=$con->prepare("SELECT * FROM playstore_apps_data WHERE category=? LIMIT 10");
                                            $game_guery->bind_param("s",$cat);
                                            $game_guery->execute();
                                            $game_results=$game_guery->get_result();
                                            if($game_results->num_rows>0)
                                            {
                                                while($games_row=$game_results->fetch_assoc())
                                                {

                                                    $game_icon=$games_row['img_url'];
                                                    $id=$games_row['id'];
                                                    $game_name=$games_row['app_name'];
                                                    $game_slug=$games_row['slug'];

                                        ?>
                                    
                                        <tr>
                                        
                                        <td><img src="<?php echo $game_icon ?>=w32"   alt="<?php echo $game_name ?>" >
                                        </td>
                                        <td style="text-align:left;"><span><a href="single?mid=<?php echo $game_slug ?>"><?php echo $game_name  ?></a></span></td>
                                        </tr>

                                                <?php }
                                                }
                                                $game_guery->close() ?>
                                       
        
                                        </tbody>
                                    </table>

                            </div>
                       

                    </div>
                </div>
            </div>
            <br>
            <div class="fluid-container" id="footer">
                
                <div class="row">
                    <div class="col-2"></div>
                    <div class="col-8"><p style="color: #fff; text-align: center;">© 2020 All copyrights Reserved Appsforwindows</p></div>
                    <div class="col-2"></div>
                </div>

                
            </div>
            


    </body>

</html>

