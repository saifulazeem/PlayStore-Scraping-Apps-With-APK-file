<html>
    <head>
        <meta charset="utf-8">
    
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>
                404 Page Not Found
        </title>

        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
        <link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">

        <script src="https://kit.fontawesome.com/4cc19ef96e.js" crossorigin="anonymous"></script>

    </head>

    <body>
        
        
            <div class="fluid-container sticky-top" id="navbar-header">
                <div class="container">
                    <div class="row">
                        <div class="col-4">
                            <br>
                            <a href="index.php"><h3 style="color: #fff;">Apps on Windows</h3></a>
                        </div>
                        <div class="col-8 ">

                            <br>
                            <br>

                            <nav class="" id="ul-container">
                                
                                <ul>
                                    <li><a  href="index.php">HOME</a></li>
                                    <li><a href="single.php">APPS</a></li>
                                    <li><a  href="contactus.html">CONTACT US</a></li>
                                    <li><a  href="aboutus.html">ABOUT US</a></li>
                                </ul>
                            </nav>    
                        </div>
                    </div>
                    
                </div>
            </div>
            
            <!-- <div class="container" id="search-container">
               
            </div> -->
            
            
            <div class="container" id="main-body">
                <br>
               
                <div class="row" style="padding-top:100px;">
                    <div class="col-2"></div>
                    <div class="col-8">
                            <!-- <form class="md-form active-cyan active-cyan-2 mb-3">
                                <input class="form-control" type="search" name="search_feild" placeholder="Search for Apps">
                                <button class="btn btn-primary">Search</button>
                            </form> -->
                            <div class="contact-form" style="text-align:center;">
                                <h3 style="color: #4d4d4d; margin-top:200px;">OOPS!!! 404 PAGE NOT FOUND</h3>
        
                            </div>
                    </div>
                    <div class="col-2"></div>
                </div>
                <br>
                <br>
                
            </div>
            <br>
            <br>
            <br>
            <div class="fluid-container" id="footer">
               
                <div class="row">
                    <div class="col-2"></div>
                    <div class="col-8"><p style="color: #fff; text-align: center;">© 2020 All copyrights Reserved Appsforwindows</p></div>
                    <div class="col-2"></div>
                </div>

                
            </div>
            


    </body>

</html>